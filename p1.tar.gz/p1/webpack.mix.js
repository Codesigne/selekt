const mix = require('laravel-mix');
const tailwindcss = require('tailwindcss')
mix
  // .js('resources/js/app.js', 'public/js')
  .sass('src/scss/app.scss', 'dist/css')
  .options({
    processCssUrls: false,
    postCss: [tailwindcss('tailwind.config.js')],
  })
  .webpackConfig({
    devServer: {
      contentBase: path.join(__dirname, 'dist'),
      compress: true,
      port: 9001,
      host: '192.168.1.147',
    }
  })
  //  .browserSync('my-domain.test');


// mix.sass('resources/sass/app.scss', 'public/css')
